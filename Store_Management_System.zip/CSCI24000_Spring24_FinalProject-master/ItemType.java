public enum ItemType {
    FASTFOOD,
    RESTAURANT,
    DRINK,
    BREAKFAST,
    LUNCH,
    DINNER,
    SNACK
}

